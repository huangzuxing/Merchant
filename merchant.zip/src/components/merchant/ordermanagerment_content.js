import React from 'react';
import ReactDOM from 'react-dom';
import "../../css/merchant/ordermanagerment.css"
/*
* 订单管理区
* */
export default class OrderManagermentContent extends React.Component{
    render(){
        return <div className="content-right">
            <div className="tpl-content-nav">
                <div className="menu">
                    <ul>
                        <li><a href="JavaScript:void(0)">订单管理</a></li>
                    </ul>
                </div>
            </div>
            <div className="am-g">
                <div className="cm-nav-tabs">
                    <div className="nav-date"></div>
                    <div className="nav-order">
                        <input type="text" placeholder="输入消费订单编号搜索订单"/>
                        <div className="nav-right">
                            <i className="iconfont">&#xe60c;</i>
                        </div>
                    </div>
                    <div className="nav-c-return">
                        <ul>
                            <li className="active">
                                <div className="nav-left"> 全部  </div>
                                <div className="nav-right">
                                    <i className="iconfont">&#xe642;</i>
                                </div>
                            </li>
                            <li><div className="nav-left"> 已返现  </div>
                                <div className="nav-right">
                                    <i className="iconfont">&#xe642;</i>
                                </div></li>
                            <li>
                                <div className="nav-left"> 未返现  </div>
                                <div className="nav-right">
                                    <i className="iconfont">&#xe642;</i>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <div className="cm-table">
                    <table className="am-table am-table-hover table-main-n">
                        <thead>
                        <tr>
                            <th style={{width:"16%"}}>用户名称</th>
                            <th style={{width:"16%"}}>消费金额</th>
                            <th style={{width:"16%"}}>消费日期</th>
                            <th style={{width:"16%"}}>是否返现</th>
                            <th style={{width:"16%"}}>订单编号</th>
                            <th style={{width:"16%"}}>订单详情</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td><img src="" alt="" className="user-invate"/>
                                <p className="am-user-name">赵四</p></td>
                            <td>52021元</td>
                            <td>2017-08-05 22:21</td>
                            <td>已返</td>
                            <td>450622153454565454445</td>
                            <td>
                                <div className="c-msg">
                                    <div className="c-datail">详情</div>
                                    <div className="details-list-one">
                                        <div className="main">
                                            <div className="main_header">
                                                <div className="bank">
                                                    <p>中国银行（尾号5421马云）</p>
                                                </div>
                                                <div className="money">
                                                    <p>-251.5</p>
                                                </div>
                                                <div className="acount">
                                                    <div className="left">
                                                        <p>实到账金额-200</p>
                                                    </div>
                                                    <div className="right">
                                                        <p>手续费 0.1</p>
                                                    </div>
                                                </div>
                                            </div>
                                            <ul className="main_list">
                                                <li className="item_list">
                                                    <div className="left">
                                                        <p>提现方式</p>
                                                    </div>
                                                    <div className="right">
                                                        <p>银行卡提现</p>
                                                    </div>
                                                </li>
                                                <li className="item_list">
                                                    <div className="left">
                                                        <p>提现时间</p>
                                                    </div>
                                                    <div className="right">
                                                        <p>2017-07-11 12:21:12</p>
                                                    </div>
                                                </li>
                                                <li className="item_list">
                                                    <div className="left">
                                                        <p>提现状态</p>
                                                    </div>
                                                    <div className="right">
                                                        <p>已提交</p>
                                                    </div>
                                                </li>
                                                <li className="item_list">
                                                    <div className="left">
                                                        <p>到账时间</p>
                                                    </div>
                                                    <div className="right">
                                                        <p>今日18时前/明日1时前</p>
                                                    </div>
                                                </li>
                                                <li className="item_list">
                                                    <div className="left">
                                                        <p>订单号</p>
                                                    </div>
                                                    <div className="right">
                                                        <p>20213322556332255633115</p>
                                                        <span>复制</span>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td><img src="" alt="" className="user-invate"/>
                                <p className="am-user-name">赵四</p></td>
                            <td>52021元</td>
                            <td>2017-08-05 22:21</td>
                            <td>已返</td>
                            <td>450622153454565454445</td>
                            <td>
                                <div className="c-msg">
                                    <div className="c-datail">详情</div>
                                    <div className="details-list-one">
                                        <div className="main">
                                            <div className="main_header">
                                                <div className="bank">
                                                    <p>中国银行（尾号5421马云）</p>
                                                </div>
                                                <div className="money">
                                                    <p>-251.5</p>
                                                </div>
                                                <div className="acount">
                                                    <div className="left">
                                                        <p>实到账金额-200</p>
                                                    </div>
                                                    <div className="right">
                                                        <p>手续费 0.1</p>
                                                    </div>
                                                </div>
                                            </div>
                                            <ul className="main_list">
                                                <li className="item_list">
                                                    <div className="left">
                                                        <p>提现方式</p>
                                                    </div>
                                                    <div className="right">
                                                        <p>银行卡提现</p>
                                                    </div>
                                                </li>
                                                <li className="item_list">
                                                    <div className="left">
                                                        <p>提现时间</p>
                                                    </div>
                                                    <div className="right">
                                                        <p>2017-07-11 12:21:12</p>
                                                    </div>
                                                </li>
                                                <li className="item_list">
                                                    <div className="left">
                                                        <p>提现状态</p>
                                                    </div>
                                                    <div className="right">
                                                        <p>已提交</p>
                                                    </div>
                                                </li>
                                                <li className="item_list">
                                                    <div className="left">
                                                        <p>到账时间</p>
                                                    </div>
                                                    <div className="right">
                                                        <p>今日18时前/明日1时前</p>
                                                    </div>
                                                </li>
                                                <li className="item_list">
                                                    <div className="left">
                                                        <p>订单号</p>
                                                    </div>
                                                    <div className="right">
                                                        <p>20213322556332255633115</p>
                                                        <span>复制</span>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td><img src="" alt="" className="user-invate"/>
                                <p className="am-user-name">赵四</p></td>
                            <td>52021元</td>
                            <td>2017-08-05 22:21</td>
                            <td>已返</td>
                            <td>450622153454565454445</td>
                            <td>
                                <div className="c-msg">
                                    <div className="c-datail">详情</div>
                                    <div className="details-list-one">
                                        <div className="main">
                                            <div className="main_header">
                                                <div className="bank">
                                                    <p>中国银行（尾号5421马云）</p>
                                                </div>
                                                <div className="money">
                                                    <p>-251.5</p>
                                                </div>
                                                <div className="acount">
                                                    <div className="left">
                                                        <p>实到账金额-200</p>
                                                    </div>
                                                    <div className="right">
                                                        <p>手续费 0.1</p>
                                                    </div>
                                                </div>
                                            </div>
                                            <ul className="main_list">
                                                <li className="item_list">
                                                    <div className="left">
                                                        <p>提现方式</p>
                                                    </div>
                                                    <div className="right">
                                                        <p>银行卡提现</p>
                                                    </div>
                                                </li>
                                                <li className="item_list">
                                                    <div className="left">
                                                        <p>提现时间</p>
                                                    </div>
                                                    <div className="right">
                                                        <p>2017-07-11 12:21:12</p>
                                                    </div>
                                                </li>
                                                <li className="item_list">
                                                    <div className="left">
                                                        <p>提现状态</p>
                                                    </div>
                                                    <div className="right">
                                                        <p>已提交</p>
                                                    </div>
                                                </li>
                                                <li className="item_list">
                                                    <div className="left">
                                                        <p>到账时间</p>
                                                    </div>
                                                    <div className="right">
                                                        <p>今日18时前/明日1时前</p>
                                                    </div>
                                                </li>
                                                <li className="item_list">
                                                    <div className="left">
                                                        <p>订单号</p>
                                                    </div>
                                                    <div className="right">
                                                        <p>20213322556332255633115</p>
                                                        <span>复制</span>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        </tbody>
                    </table>
                </div>
                <div className="am-jump">
                    <div className="sub-jump">
                        <ul>
                            <li className="j-prev"/>
                            <li><p>2/12</p></li>
                            <li className="j-next"/>
                            <li><input type="text"/></li>
                            <li className="jump">跳转</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    }
}