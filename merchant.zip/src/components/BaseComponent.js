import React from 'react';
import ReactDOM from 'react-dom';

export default class BaseComponent extends React.Component {

}